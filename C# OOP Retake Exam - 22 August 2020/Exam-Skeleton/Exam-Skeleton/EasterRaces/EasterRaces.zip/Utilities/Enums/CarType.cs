﻿
namespace EasterRaces.Utilities.Enums
{
    public enum CarType
    {
        Muscle = 1,
        Sports = 2
    }
}
